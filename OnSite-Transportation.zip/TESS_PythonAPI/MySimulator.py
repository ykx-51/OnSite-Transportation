import random
from PySide2.QtCore import QObject, Qt, Signal
from tessng import PyCustomerSimulator, tessngIFace, Online, m2p
from tessng import _VehicleType, UnitOfMeasure
import math, itertools
import transit
import pandas as pd

class MySimulator(PyCustomerSimulator, QObject):
    forStopSimu = Signal()
    forReStartSimu = Signal()
    showRunInfo = Signal(str)

    def __init__(self):
        PyCustomerSimulator.__init__(self)
        QObject.__init__(self)
        self.iface = tessngIFace()
        self.netiface = self.iface.netInterface()
        self.simuiface = self.iface.simuInterface()
        self.guiiface = self.iface.guiInterface()
        self.main_window = self.guiiface.mainWindow()
        self.forStopSimu.connect(self.main_window.doStopSimu, Qt.QueuedConnection)
        self.forReStartSimu.connect(self.main_window.doStartSimu, Qt.QueuedConnection)
        self.current_net_name: str = ""
        self.max_simu_count: int = 0

        self.conflict_wait = {}
        self.conflict_cooldown = {}
        self.yield_wait = {}
        self.point_wait = {}
        self.point_cooldown = {}
        self.target_vehicle_list = transit.get_player_vehicle_plan()
        self.merge_player_plan(self.target_vehicle_list)
        self.controlled_by_id = {}
        self.next_stop_id1 = 120
        self.spawn_counter = {}

    def beforeStart(self, ref_keep_on: bool) -> None:
        current_net_name: str = self.netiface.netFilePath()
        if current_net_name != self.current_net_name:
            self.current_net_name = current_net_name
            self.max_simu_count = 1
        else:
            self.max_simu_count += 1

    def afterStart(self) -> None:
        vehicle_type = _VehicleType()
        vehicle_type.vehicleTypeName = "自动驾驶集卡"
        vehicle_type.Length = 4
        vehicle_type.lengthSD = 0
        vehicle_type.width = 2
        vehicle_type.widthSD = 0
        vehicle_type.avgSpeed = 60
        vehicle_type.speedSD = 10
        vehicle_type.avgAcce = 4
        vehicle_type.acceSD = 0.5
        vehicle_type.avgDece = 6
        vehicle_type.deceSD = 0.5
        vehicle_type.maxAcce = 5.5
        vehicle_type.maxDece = 7.5
        vehicle_type.maxSpeed = 80
        vehicle_type.commercialVehicle = False
        vehicle_type.maxPassengerCapacity = 1
        result = self.netiface.createVehicleType(vehicle_type)

        vehicle_type = _VehicleType()
        vehicle_type.vehicleTypeName = "人工驾驶集卡"
        vehicle_type.Length = 4
        vehicle_type.lengthSD = 0
        vehicle_type.width = 2
        vehicle_type.widthSD = 0
        vehicle_type.avgSpeed = 40
        vehicle_type.speedSD = 10
        vehicle_type.avgAcce = 4
        vehicle_type.acceSD = 0.5
        vehicle_type.avgDece = 6
        vehicle_type.deceSD = 0.5
        vehicle_type.maxAcce = 5.5
        vehicle_type.maxDece = 7.5
        vehicle_type.maxSpeed = 80
        vehicle_type.commercialVehicle = False
        vehicle_type.maxPassengerCapacity = 1
        result = self.netiface.createVehicleType(vehicle_type)

    def afterStop(self) -> None:
        if self.max_simu_count >= 1:
            return
        self.forReStartSimu.emit()

    def afterOneStep(self) -> None:
        simu_accuracy: int = self.simuiface.simuAccuracy()
        # 仿真倍速
        simu_multiples: int = self.simuiface.acceMultiples()
        self.simuiface.setAcceMultiples(5)  # 设置仿真倍速
        # 当前仿真计算批次
        batch_number = self.simuiface.batchNumber()
        # 当前已仿真时间，单位：毫秒
        simu_time = self.simuiface.simuTimeIntervalWithAcceMutiples()
        # 如果仿真时间比所有任务的计划完成时刻晚？min，通知主窗体停止仿真
        task = pd.read_csv("Output/task.csv", encoding="gbk", engine="python")
        task["计划开始时刻"] = pd.to_datetime(task["计划开始时刻"], format="%H:%M")
        task["计划结束时刻"] = pd.to_datetime(task["计划结束时刻"], format="%H:%M")
        start_time = task.iloc[0]["计划开始时刻"]
        end_time = task.iloc[-1]["计划结束时刻"]
        time_delta = end_time - start_time
        total_ms = time_delta.total_seconds() * 1000
        buffer_ms = 30 * 60 * 1000  # 30 分钟
        if simu_time >= total_ms + buffer_ms:
            self.forStopSimu.emit()
            print("仿真结束")

        new_plan = transit.get_player_vehicle_plan()
        existing_ids = {v["id"] for v in self.target_vehicle_list}
        for item in new_plan:
            if item.get("id") not in existing_ids:
                self.target_vehicle_list.append(item)
        self.merge_player_plan(new_plan)

        all_vehicles = self.simuiface.allVehiStarted()
        for vehicle in all_vehicles:
            if simu_time % 1000 == 0:
                transit.write_vehicle_state(
                    vehicle_id=vehicle.id(),
                    vehicle_type=vehicle.vehicleTypeCode(),
                    x=vehicle.pos(UnitOfMeasure.Metric).x(),
                    y=vehicle.pos(UnitOfMeasure.Metric).y(),
                    road_id=vehicle.roadId(),
                    lane_id=vehicle.laneId(),
                    speed_ms=vehicle.currSpeed(UnitOfMeasure.Metric),
                    angle_deg=vehicle.angle(),
                    dist_to_start=vehicle.vehicleDriving().distToStartPoint(True, True, UnitOfMeasure.Metric),
                    simu_time=simu_time
                )

        # 在信息窗显示信息
        if batch_number % simu_accuracy == 0:
            # 路段数量
            link_count: int = self.netiface.linkCount()
            # 车辆数
            vehicle_count: int = len(all_vehicles)
            run_info: str = f"路段数：{link_count}\n运行车辆数：{vehicle_count}\n仿真时间：{simu_time}(毫秒)"
            self.showRunInfo.emit(run_info)

        for cfg in self.target_vehicle_list:

            if cfg["state"] == 0 and simu_time / 1000 == cfg["send_time"]:
                dvp = Online.DynaVehiParam()
                dvp.vehiTypeCode = 15
                dvp.roadId = cfg["roadId"]
                dvp.laneNumber = 0
                dvp.dist = 5
                dvp.speed = 10
                dvp.color = "#00FF00"

                created = None
                try:
                    created = self.simuiface.createGVehicle(dvp)
                except Exception:
                    created = None

                if created is not None:
                    try:
                        vid = created.id()
                        cfg["id"] = vid
                        cfg["state"] = 2
                        self.controlled_by_id[vid] = cfg
                        try:
                            transit.write_id_record(cfg["id"])
                        except Exception as e:
                            print("写入 id 文件失败：", e)
                    except Exception:
                        cfg["state"] = 1
                else:
                    cfg["state"] = 1

        for cfg in self.target_vehicle_list:
            if cfg["state"] == 1:
                for v in all_vehicles:
                    try:
                        if v.color() == "#00FF00" and v.roadId() == cfg["roadId"]:
                            cfg["id"] = v.id()
                            cfg["state"] = 2
                            self.controlled_by_id[cfg["id"]] = cfg
                            try:
                                transit.write_id_record(cfg["id"])
                            except Exception as e:
                                print("写入 id 文件失败：", e)
                            break
                    except Exception:
                        continue

        for cfg in self.target_vehicle_list:
            if cfg["state"] != 2:
                continue
            vid = cfg["id"]
            vobj = None
            for v in all_vehicles:
                if v.id() == vid:
                    vobj = v
                    break
            if vobj is None:
                continue

            if cfg.get("routing_link_ids"):
                try:
                    link_ids = cfg["routing_link_ids"]
                    curr_road = vobj.roadId()

                    if "_current_idx" not in cfg or cfg["_current_idx"] is None:
                        cfg["_current_idx"] = 0

                    idx = cfg["_current_idx"]

                    if idx >= len(link_ids):
                        return

                    if idx + 1 < len(link_ids):
                        next_expected = link_ids[idx + 1]

                        if curr_road == next_expected:
                            cfg["_current_idx"] += 1
                            idx += 1

                    remaining_link_ids = link_ids[idx:]

                    sub_links = []
                    for lid in remaining_link_ids:
                        link_obj = self.netiface.findLink(lid)
                        if link_obj is not None:
                            sub_links.append(link_obj)

                    if sub_links:
                        try:
                            new_routing = self.netiface.createRouting(sub_links)
                            cfg["routing"] = new_routing
                            vobj.vehicleDriving().setRouting(new_routing)
                        except Exception:
                            pass

                except Exception:
                    pass

            if vobj.laneId() == 0:
                continue
            dist1 = vobj.vehicleDriving().distToEndpoint(True)
            dist2 = vobj.vehicleDriving().distToStartPoint(True, True, UnitOfMeasure.Metric)
            if dist1 < m2p(20) or dist2 < 20:
                continue
            if cfg.get("lane_cmd") is not None:
                try:
                    if cfg["lane_cmd"] == 1:
                        vobj.vehicleDriving().toLeftLane()
                    elif cfg["lane_cmd"] == 2:
                        vobj.vehicleDriving().toRightLane()
                except Exception:
                    pass

            max_speed = 80/3.6
            if cfg.get("speed_value") is not None:
                try:
                    speed = min(max_speed, cfg["speed_value"])
                    vobj.setDesirSpeed(speed)
                except Exception:
                    pass

        vehicle_count: int = len(all_vehicles)
        if batch_number % 40 == 1 and vehicle_count <= 200:

            spawn_list1 = [
                dict(key="red1", max_total=100, vehiTypeCode=15, roadId=16, lane_range=(0, 2),
                     dist=5, speed=20, color="#FF0000"),
                dict(key="red2", max_total=100, vehiTypeCode=15, roadId=8, lane_range=(0, 2),
                     dist=5, speed=20, color="#FF0000"),
                dict(key="yellow1", max_total=50, vehiTypeCode=16,roadId=75,lane_range=(0, 2),
                     dist=5, speed=20, color="#556B2F"),
                dict(key="red3", max_total=100, vehiTypeCode=15, roadId=26, lane_range=(0, 2),
                     dist=5, speed=20, color="#FF0000"),

                dict(key="red4", max_total=100, vehiTypeCode=15, roadId=54, lane_range=(0, 2),
                     dist=5, speed=20, color="#FF0000"),

            ]

            for vvv in spawn_list1:
                key = vvv["key"]
                max_total = vvv["max_total"]
                already = self.spawn_counter.get(key, 0)

                if already >= max_total:
                    continue

                vvv_for_spawn = vvv.copy()
                vvv_for_spawn.pop("key")
                vvv_for_spawn.pop("max_total")

                created = self.spawn_vehicle(**vvv_for_spawn)

                # 发车成功才计数
                if created:
                    self.spawn_counter[key] = already + 1

        stop_id1 = self.next_stop_id1
        self.next_stop_id1 = 121 if self.next_stop_id1 == 120 else 120
        link_id_list1 = [75, 18, 270, 214, stop_id1]
        link_id_list2 = [210, 213, 215, 74, 201]

        link_list1 = [self.netiface.findLink(link_id) for link_id in link_id_list1]
        link_list2 = [self.netiface.findLink(link_id) for link_id in link_id_list2]

        routing1 = self.netiface.createRouting(link_list1)
        routing2 = self.netiface.createRouting(link_list2)

        for v in all_vehicles:
            if v.vehicleTypeCode() == 16:
                if v.roadId() == 75:
                    v.vehicleDriving().setRouting(routing1)
                if v.roadId() == 210:
                    v.vehicleDriving().setRouting(routing2)

        for v1, v2 in itertools.combinations(all_vehicles, 2):

            if v1.vehicleTypeCode() != 15 or v2.vehicleTypeCode() != 15:
                continue

            if v1.laneId() != 0 or v2.laneId() != 0:
                continue

            id1, id2 = v1.id(), v2.id()

            pair_id = (min(id1, id2), max(id1, id2))
            if pair_id in self.conflict_cooldown:
                if simu_time < self.conflict_cooldown[pair_id]:
                    continue
                else:
                    del self.conflict_cooldown[pair_id]

            if id1 in self.conflict_wait or id2 in self.conflict_wait:
                continue

            a1 = v1.angle()
            a2 = v2.angle()
            a = abs(a1 - a2)
            if a < 90 or a > 270:
                continue

            l1 = v1.length(UnitOfMeasure.Metric)
            l2 = v2.length(UnitOfMeasure.Metric)
            x1 = v1.pos(UnitOfMeasure.Metric).x()
            y1 = v1.pos(UnitOfMeasure.Metric).y()
            x2 = v2.pos(UnitOfMeasure.Metric).x()
            y2 = v2.pos(UnitOfMeasure.Metric).y()
            rad1 = math.radians(a1)
            rad2 = math.radians(a2)
            x1_head_ = x1 + (l1 / 2.0 + 1.5) * math.sin(rad1)
            y1_head_ = y1 - (l1 / 2.0 + 1.5) * math.cos(rad1)
            x2_head_ = x2 + (l2 / 2.0 + 1.5) * math.sin(rad2)
            y2_head_ = y2 - (l2 / 2.0 + 1.5) * math.cos(rad2)

            distance1 = math.hypot(x1_head_ - x2_head_, y1_head_ - y2_head_)

            if distance1 > 1.5:
                continue

            wait_time_ms = 3 * 60 * 1000
            end_time = simu_time + wait_time_ms
            self.conflict_wait[v1.id()] = end_time
            self.conflict_wait[v2.id()] = end_time

            cooldown_ms = 10 * 1000
            self.conflict_cooldown[pair_id] = end_time + cooldown_ms

            transit.write_penalty_record({"butt": v1.id()})
            transit.write_penalty_record({"butt": v2.id()})

            print(f"车辆 {v1.id()} 顶牛结束时间（s）：{end_time / 1000:.2f}")
            print(f"车辆 {v2.id()} 顶牛结束时间（s）：{end_time / 1000:.2f}")
            print("v1路段ID:", v1.roadId())
            print("v2路段ID:", v2.roadId())

        for v1, v2 in itertools.combinations(all_vehicles, 2):

            type1 = v1.vehicleTypeCode()
            type2 = v2.vehicleTypeCode()

            if {type1, type2} != {15, 16}:
                continue

            auto = v1 if type1 == 15 else v2
            human = v2 if auto is v1 else v1

            if auto.id() in self.yield_wait:
                continue

            if v1.laneId() != 0 or v2.laneId() != 0:
                continue

            a1 = auto.angle()
            a2 = human.angle()
            diff = abs(a1 - a2)
            if diff < 90 or diff > 270:
                continue

            l1 = v1.length(UnitOfMeasure.Metric)
            l2 = v2.length(UnitOfMeasure.Metric)
            x1 = v1.pos(UnitOfMeasure.Metric).x()
            y1 = v1.pos(UnitOfMeasure.Metric).y()
            x2 = v2.pos(UnitOfMeasure.Metric).x()
            y2 = v2.pos(UnitOfMeasure.Metric).y()
            rad1 = math.radians(a1)
            rad2 = math.radians(a2)
            x1_head_ = x1 + (l1 / 2.0 + 1.5) * math.sin(rad1)
            y1_head_ = y1 - (l1 / 2.0 + 1.5) * math.cos(rad1)
            x2_head_ = x2 + (l2 / 2.0 + 1.5) * math.sin(rad2)
            y2_head_ = y2 - (l2 / 2.0 + 1.5) * math.cos(rad2)
            distance1 = math.hypot(x1_head_ - x2_head_, y1_head_ - y2_head_)

            if distance1 > 1.5:
                continue

            wait_ms = 1 * 1000
            end_time = simu_time + wait_ms

            self.yield_wait[auto.id()] = end_time

            transit.write_penalty_record({"conflict": auto.id()})

            print(f"自动驾驶车辆 {auto.id()} 避让人工驾驶 {human.id()} ，当前时刻：{simu_time / 1000:.2f} 秒 ，将停止到：{end_time / 1000:.2f} 秒")

        SPECIAL_ROADS = {273, 279, 285, 291, 108, 122, 163, 136}
        for v in all_vehicles:
            vid = v.id()

            if vid in self.point_wait:
                continue

            if vid in self.point_cooldown:
                if simu_time < self.point_cooldown[vid]:
                    continue
                else:
                    del self.point_cooldown[vid]

            if v.roadId() not in SPECIAL_ROADS:
                continue

            try:
                dist = v.vehicleDriving().distToStartPoint(True, True, UnitOfMeasure.Metric)
            except:
                continue

            if abs(dist - 150) > 2:
                continue

            wait_ms = int(random.normalvariate(120000, 15000))
            end_time = simu_time + wait_ms
            self.point_wait[vid] = end_time

            road_id = v.roadId()
            transit.write_operation_state(
                vehicle_id=vid,
                road_id=road_id,
                state=1,
                simu_time=simu_time,
                wait_ms=wait_ms,
                end_time=end_time
            )

            COOLDOWN_MS = 10 * 1000
            self.point_cooldown[vid] = end_time + COOLDOWN_MS

    def merge_player_plan(self, new_plan):
        IMMUTABLE_AFTER_INIT = {"send_time", "roadId"}
        PLATFORM_ONLY_FIELDS = {"state", "id", "routing", "_current_idx"}
        PLAYER_ALLOWED_FIELDS = {"routing_link_ids", "lane_cmd", "speed_value"}

        for new_item in new_plan:
            vid = new_item.get("id")
            if vid is None:
                continue

            old_item = None
            for c in self.target_vehicle_list:
                if c.get("id") == vid:
                    old_item = c
                    break
            if old_item is None:
                continue

            for f in IMMUTABLE_AFTER_INIT.union(PLATFORM_ONLY_FIELDS):
                if f in new_item and new_item[f] != old_item.get(f):
                    new_item[f] = old_item.get(f)

            for f in PLAYER_ALLOWED_FIELDS:
                if f in new_item:
                    allow = True

                    now = self.simuiface.simuTimeIntervalWithAcceMutiples()
                    last = old_item.get(f"_last_update_{f}", -10**12)

                    if f == "routing_link_ids":

                        new_route = new_item[f]
                        old_route = old_item.get(f)

                        new_special = self.extract_special_order(new_route)
                        old_special = old_item.get("_last_special_order", self.extract_special_order(old_route))

                        now = self.simuiface.simuTimeIntervalWithAcceMutiples()

                        last_route_update = old_item.get("_last_update_routing_link_ids", -10 ** 12)
                        last_special_update = old_item.get("_last_special_update", -10 ** 12)

                        special_changed = (new_special != old_special)

                        if special_changed:
                            if now - last_special_update < 600000:  # 600s
                                allow = False
                            else:
                                allow = True
                                old_item["_last_special_update"] = now
                                old_item["_last_special_order"] = new_special
                                old_item["_last_update_routing_link_ids"] = now

                        else:
                            if now - last_route_update < 60000:
                                allow = False
                            else:
                                allow = True
                                old_item["_last_update_routing_link_ids"] = now

                        if allow:
                            old_item[f] = new_route

                    elif f == "lane_cmd":
                        if now - last < 1000:
                            allow = False

                    if allow:
                        old_item[f] = new_item[f]
                        old_item[f"_last_update_{f}"] = now

                    elif f == "speed_value":
                        if now - last < 10000:
                            allow = False

                    if allow:
                        old_item[f] = new_item[f]
                        old_item[f"_last_update_{f}"] = now

    def spawn_vehicle(self, *, vehiTypeCode, roadId, lane_range,
                      dist, speed, color):
        dvp = Online.DynaVehiParam()
        dvp.vehiTypeCode = vehiTypeCode
        dvp.roadId = roadId
        dvp.laneNumber = random.randint(*lane_range)
        dvp.dist = dist
        dvp.speed = speed
        dvp.color = color
        try:
            return self.simuiface.createGVehicle(dvp)
        except Exception:
            return None

    def extract_special_order(self, routing_link_ids):
        SPECIAL_ROADS = {273, 279, 285, 291, 108, 122, 163, 136}
        return [rid for rid in routing_link_ids if rid in SPECIAL_ROADS]

    def ref_reSetSpeed(self, vehicle, ref_inOutSpeed) -> bool:
        vid = vehicle.id()
        simu_time = self.simuiface.simuTimeIntervalWithAcceMutiples()
        if vid in self.conflict_wait:
            if simu_time < self.conflict_wait[vid]:
                ref_inOutSpeed.value = 0.0
                return True
            else:
                del self.conflict_wait[vid]
                ref_inOutSpeed.value = 10
                print(f"车辆 {vid} 顶牛结束了，当前仿真时间（s）：{simu_time / 1000:.2f}")
                return True

        if vid in self.yield_wait:
            if simu_time < self.yield_wait[vid]:
                ref_inOutSpeed.value = 0.0
                return True
            else:
                del self.yield_wait[vid]
                ref_inOutSpeed.value = 10
                print(f"自动驾驶车辆 {vid} 避让结束，仿真时间：{simu_time / 1000:.2f} 秒")
                return True

        if vid in self.point_wait:
            if simu_time < self.point_wait[vid]:
                ref_inOutSpeed.value = 0.0
                return True
            else:
                del self.point_wait[vid]
                ref_inOutSpeed.value = 10
                road_id = vehicle.roadId()
                transit.write_operation_state(
                    vehicle_id=vid,
                    road_id=road_id,
                    state=0,
                    wait_ms=0,
                    end_time=0,
                    simu_time=simu_time
                )
                return True

        return False

    def set_steps_per_call(self, vehicle) -> None:
        if vehicle.vehicleTypeCode() == 15:
            vehicle.setSteps_reSetSpeed(1)
        else:
            steps = self.simuiface.simuAccuracy()
            vehicle.setSteps_reSetSpeed(steps * 300)

    def isStopDriving(self, vehicle) -> bool:
        if vehicle.vehicleTypeCode() == 16:
            if vehicle.roadId() == 201:
                dist = vehicle.vehicleDriving().distToEndpoint(True)
                if dist < m2p(50):
                    return True
        return False

    def afterStopVehicle(self, vehicle) -> None:
        pass
