import pandas as pd
import csv
import time
import ast
import os
import transit

def open_file_lazy(path, file_handle):
    """
    懒加载打开文件：
    - 仅当文件存在且未打开时打开
    - 跳到文件末尾，忽略历史数据
    - 读取异常时自动关闭
    """
    # 如果已经有句柄，直接返回
    if file_handle is not None:
        return file_handle

    # 文件存在才打开
    if os.path.exists(path):
        try:
            f = open(path, "r")
            f.seek(0, os.SEEK_END)  # 跳到末尾
            return f
        except:
            return None
    return None

def read_csv_new_lines(file_handle, data_list):
    """
    读取文件中新追加的行，并更新到 data_list
    - file_handle: 打开的文件对象
    - data_list: 用于存储所有读取数据的列表
    返回: file_handle（如果文件被删除或异常会返回 None）
    """
    if file_handle is None:
        return None

    try:
        new_lines = file_handle.readlines()
        if new_lines:
            reader = csv.DictReader(new_lines)
            data_list.extend(list(reader))
        return file_handle
    except:
        # 文件异常时关闭句柄
        try: file_handle.close()
        except: pass
        return None

def run_baseline(update_plan_fn):
    # 静态输入
    input1_1 = pd.read_csv("车道.csv", encoding="gbk", engine="python")
    input1_2 = pd.read_csv("车道连接.csv", encoding="gbk", engine="python")
    input2 = pd.read_csv("Output/task.csv", encoding="gbk", engine="python")
    input2 = input2.dropna()
    input3 = pd.read_csv("vehicle.csv", encoding="gbk", engine="python")
    # 动态输入
    input4 = "vehicle_state.csv"
    input5 = "Output/operation_state.csv"
    input6 = "Output/id.csv"

    # 先删除旧文件
    transit.init_output_files()

    vehicle_file = None
    operation_file = None
    id_file = None

    vehicle_data = []
    operation_data = []
    id_data = []

    # 目前的更新逻辑是if xxx is None: , 选手在编写自己的算法时，也可以用条件判断来限制更新
    # 否则计划一直在更新，会从大于等于固定频率更新被采纳变成固定频率更新被采纳
    vehicle_tasks = None
    vehicle_route = None
    vehicle_lane = None
    vehicle_speed = None
    plan_sent = None

    while True:

        # 读取动态输入的方式，供选手参考
        # ===== 懒加载打开文件 =====
        vehicle_file = open_file_lazy(input4, vehicle_file)
        operation_file = open_file_lazy(input5, operation_file)
        id_file = open_file_lazy(input6, id_file)

        # ===== 读取新数据 =====
        vehicle_file = read_csv_new_lines(vehicle_file, vehicle_data)
        operation_file = read_csv_new_lines(operation_file, operation_data)
        id_file = read_csv_new_lines(id_file, id_data)

        # ---------- 算法逻辑 ----------
        # 1.任务分配

        # 选手的任务分配算法，选手自己补充；若无，按批次顺序平均分配任务

        # 按批次顺序平均分配任务
        if vehicle_tasks is None:

            vehicle_num = int(input3["数量"].iloc[0])
            global_start = 82
            global_end = 191

            vehicle_tasks = [[] for _ in range(vehicle_num)]

            # 按批次顺序执行
            for _, row in input2.iterrows():
                quantity = int(row["数量"])
                origin = int(row["起点"])
                destination = int(row["终点"])

                base = quantity // vehicle_num
                remainder = quantity % vehicle_num

                for v in range(vehicle_num):
                    task_count = base + (1 if v < remainder else 0)

                    for _ in range(task_count):
                        vehicle_tasks[v].extend([origin, destination])

            # 加总起点终点
            for v in range(vehicle_num):
                vehicle_tasks[v] = [global_start] + vehicle_tasks[v] + [global_end]
        # 输出的车辆任务示例，起点与终点也算任务节点
        '''
        vehicle_tasks = [
            [82, 273, 108, 273, 108, 279, 122, 191],  # 第一辆车的任务节点
            [82, 273, 108, 273, 108, 279, 122, 191],
            [82, 273, 108, 273, 108, 279, 122, 191],
            [82, 273, 108, 273, 108, 279, 122, 191],
            [82, 273, 108, 273, 108, 279, 122, 191],
        ]
        '''

        # 2.路径规划

        # 选手的路径规划算法，选手自己补充；若无，以作业设备间的最短路填充

        # 以作业设备间的最短路填充
        if vehicle_route is None:
            # 构建 (u, v) -> 最短路径 的字典
            shortest_path = pd.read_csv("Shortest path.csv")
            shortest_path_dict = {}

            for _, row in shortest_path.iterrows():
                od = ast.literal_eval(row.iloc[0])  # [273,108]
                path = ast.literal_eval(row.iloc[1])  # [273,88,...,108]
                u, v = int(od[0]), int(od[1])
                shortest_path_dict[(u, v)] = path
            # 生成每辆车的全过程路径
            vehicle_route = []

            for tasks in vehicle_tasks:
                full_route = []

                for i in range(len(tasks) - 1):
                    start, end = tasks[i], tasks[i + 1]

                    # 取最短路径
                    path = shortest_path_dict[(start, end)]

                    if i == 0:
                        # 第一段路径，完整加入
                        full_route.extend(path)
                    else:
                        # 后续路径，去掉起点，避免重复
                        full_route.extend(path[1:])

                vehicle_route.append(full_route)
        # 输出的车辆路径示例
        '''
        vehicle_route = [
            [273, ...... , 108,  ...... , 273,  ...... , 108,  ...... , 279,  ...... , 122],  # 第一辆车的全过程路径
            [273, ...... , 108,  ...... , 273,  ...... , 108,  ...... , 279,  ...... , 122], 
            [273, ...... , 108,  ...... , 273,  ...... , 108,  ...... , 279,  ...... , 122], 
        ]
        '''

        # 3.车速车道引导

        # 选手的车速车道引导算法，选手自己补充；若无，采用Tess Ng 的模型

        # 采用Tess Ng 的模型
        # lane_cmd（变道指令, None/1/2）, speed_value（None/期望速度的值, m/s）
        if vehicle_lane is None:
            num = int(input3.iloc[0, 0])
            vehicle_lane = [[None] for _ in range(num)]
        if vehicle_speed is None:
            num = int(input3.iloc[0, 0])
            vehicle_speed = [[None] for _ in range(num)]
        # 输出的车辆车道选择示例
        '''
        vehicle_lane = [
            [None],
            [None],
            [None],
        ]
        '''

        # 4.生成完整的车辆运输计划 + 动态更新
        new_plan = []
        num = int(input3.iloc[0, 0])

        # 输出说明
        """
        # 每个元素是 dict，包含：
            # send_time（发送时刻，单位：s）, roadId（起点路段id）, state(发送状态, 0/1/2), id（车辆id）,
            # routing_link_ids（起点到终点的完整路径）, routing（当前路段到终点的路径）, "_current_idx"（当前在路径中的位置）
            # lane_cmd（变道指令, None/1/2）, speed_value（期望速度的值, m/s）
        """

        for i in range(num):
            vehicle_plan = {
                "send_time": 5 + (i + 1) * 5,
                "roadId": vehicle_route[i][0],
                "state": 0,
                "id": None,
                "routing": None,
                "_current_idx": 0,
                "routing_link_ids": vehicle_route[i],
                "lane_cmd": vehicle_lane[i][0],
                "speed_value": vehicle_speed[i][0],
            }

            new_plan.append(vehicle_plan)

        if plan_sent is None:
           update_plan_fn(new_plan)
           plan_sent = True

        # 动态更新示例
        new_plan[0]["lane_cmd"] = 2 # 引导第一辆车的车道选择
        update_plan_fn(new_plan)

        time.sleep(0.1)  # 每0.1秒检查一次新数据，仿真倍速为5，相当于每0.5仿真秒检查一次新数据，小于1仿真秒，合理